export function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

export function assertRecord(
  value: unknown,
  label: string,
): asserts value is Record<string, unknown> {
  assert(value !== null && typeof value === "object" && !Array.isArray(value),
    `${label}: expected an object`);
}

function canonical(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonical);
  if (value !== null && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).sort(([a], [b]) => a.localeCompare(b))
        .map(([key, child]) => [key, canonical(child)]),
    );
  }
  return value;
}

export function assertEquals(actual: unknown, expected: unknown, label: string): void {
  const actualJson = JSON.stringify(canonical(actual));
  const expectedJson = JSON.stringify(canonical(expected));
  assert(actualJson === expectedJson,
    `${label}: expected ${expectedJson}, received ${actualJson}`);
}

export function assertIncludes(actual: string, expected: string, label: string): void {
  assert(actual.includes(expected), `${label}: missing ${JSON.stringify(expected)}`);
}

export async function sha256(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export function options(args: string[], allowed: string[]): Map<string, string> {
  const result = new Map<string, string>();
  for (const arg of args) {
    const match = /^--([a-z-]+)=(.+)$/.exec(arg);
    assert(match && allowed.includes(match[1]), `Unknown argument: ${arg}`);
    assert(!result.has(match[1]), `Repeated argument: ${match[1]}`);
    result.set(match[1], match[2]);
  }
  return result;
}

export function fileUrl(value: string, label: string): URL {
  const url = new URL(value);
  assert(url.protocol === "file:" && !url.search && !url.hash, `${label}: supply a plain file: URL`);
  return url;
}
